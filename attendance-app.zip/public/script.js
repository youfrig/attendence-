
document.getElementById("uploadForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    const status = document.getElementById("status");

    status.innerText = "Processing...";

    const response = await fetch("/upload", {
        method: "POST",
        body: formData
    });

    if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = url;
        a.download = "Professional_Attendance_Report.xlsx";
        a.click();

        status.innerText = "Report Generated Successfully!";
    } else {
        status.innerText = "Error processing file.";
    }
});
